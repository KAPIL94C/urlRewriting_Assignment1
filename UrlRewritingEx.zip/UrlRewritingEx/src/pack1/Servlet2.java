package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.javafx.collections.MappingChange.Map;

/**
 * Servlet implementation class Servlet2
 */
public class Servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet2() {
        super();
        // TODO Auto-generated constructor stub
    }
    HashMap<Integer,String> map = new HashMap<>();
   

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String  pincode=request.getParameter("pincode");
		String tech=request.getParameter("tech");
	
		String city = new Service().getCity(pincode); 
		String job = new Service().getJobs(tech);
		
		out.print("<html><body>");
		out.print("<h3>For pincode: "+pincode+", city: "+city+"</h3>");
		out.print("<h3>For technology: "+tech+", job profile: "+job+"</h3>");
		out.print("</body></html>");
	
		
//		for(Map.Entry<Integer, String> entry:map.entrySet()){  
//	     
//	}
	out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
