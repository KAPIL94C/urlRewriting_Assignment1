package pack1;

import java.util.HashMap;

public class Service {
	HashMap<String, String> hm = new HashMap<String, String>();
	{
		hm.put("204213", "Delhi");
		hm.put("201306", "Mumbai");
		hm.put("201308", "Banglore");
		hm.put("200020", "Pune");
	}
	
	public String getCity(String pincode)
	{
		String city="";
		city = hm.get(pincode);
		return city;
	}
	
	public String getJobs(String tech)
	{
		String job = "";
		if(tech.equalsIgnoreCase("Java"))
			job = ("Java Developer");
		else if(tech.equalsIgnoreCase("Node.js"))
			job = ("Node.js Developer");
		else if(tech.equalsIgnoreCase("Python"))
			job = "Python Developer";
		else
			job = "Oracle Developer";
		return job;
	}

}
